﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeAreDevs_API;
namespace PixPloit_2._1._1
{
    public partial class main : Form
    {
        public main()
        {
            InitializeComponent();
        }
        ExploitAPI api = new ExploitAPI();
        private void Button1_Click(object sender, EventArgs e)
        {
            api.IsUpdated();
            api.LaunchExploit();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            string text = fastColoredTextBox1.Text;
            this.api.SendLimitedLuaScript(text);
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            fastColoredTextBox1.Text = "";
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            OpenFileDialog opendialogfile = new OpenFileDialog();
            opendialogfile.Filter = "Lua File (*.lua)|*.lua|Text File (*.txt)|*.txt";
            opendialogfile.FilterIndex = 2;
            opendialogfile.RestoreDirectory = true;
            if (opendialogfile.ShowDialog() != DialogResult.OK)
                return;
            try
            {
                fastColoredTextBox1.Text = "";
                System.IO.Stream stream;
                if ((stream = opendialogfile.OpenFile()) == null)
                    return;
                using (stream)
                    this.fastColoredTextBox1.Text = System.IO.File.ReadAllText(opendialogfile.FileName);
            }
            catch (Exception ex)
            {
                int num = (int)MessageBox.Show("An unexpected error has occured", "OOF!", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
        }

        private void ListBox1_SelectedIndexChanged(object sender, EventArgs e) => fastColoredTextBox1.Text = File.ReadAllText($"./Scripts/{listBox1.SelectedItem}");

        private void Button5_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();//Clear Items in the LuaScriptList
            Functions.PopulateListBox(listBox1, "./Scripts", "*.txt");
            Functions.PopulateListBox(listBox1, "./Scripts", "*.lua");
        }

        private void Main_Load(object sender, EventArgs e)
        {
            listBox1.Items.Clear();//Clear Items in the LuaScriptList
            Functions.PopulateListBox(listBox1, "./Scripts", "*.txt");
            Functions.PopulateListBox(listBox1, "./Scripts", "*.lua");
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }
        Point lastPoint;
        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button14_Click(object sender, EventArgs e)
        {
            api.DoKill(textBox1.Text);
        }

        private void Button15_Click(object sender, EventArgs e)
        {
            api.DoKill();
            api.SendCommand("kill me");
        }

        private void Button6_Click(object sender, EventArgs e)
        {
            api.DoBTools();
            api.SendCommand("btools me");
        }

        private void Button7_Click(object sender, EventArgs e)
        {
            api.AddFire();
            api.SendCommand("fire me");
        }

        private void Button8_Click(object sender, EventArgs e)
        {
            api.AddSmoke();
            api.SendCommand("smoke me");
        }

        private void Button9_Click(object sender, EventArgs e)
        {
            api.AddSparkles();
            api.SendCommand("sparkles me");
        }

        private void Button10_Click(object sender, EventArgs e)
        {
            api.CreateForceField();
            api.SendCommand("ff me");
        }

        private void Button11_Click(object sender, EventArgs e)
        {
            api.RemoveForceField();
            api.SendCommand("noff me");
        }

        private void Button12_Click(object sender, EventArgs e)
        {
            api.RemoveFire();
            api.SendCommand("nofire me");
        }

        private void Button13_Click(object sender, EventArgs e)
        {
            api.RemoveSparkles();
            api.SendCommand("nosparkles me");
        }

        private void Button16_Click(object sender, EventArgs e)
        {

        }

        private void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            api.ToggleClickTeleport();
            MessageBox.Show("Do CTRL + Click to TP.");
        }
    }
}
