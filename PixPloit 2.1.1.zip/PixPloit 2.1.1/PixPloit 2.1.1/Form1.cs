﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeAreDevs_API;
namespace PixPloit_2._1._1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        ExploitAPI api = new ExploitAPI();
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Process.Start("https://pastebin.com/raw/Kni4aMa5");
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "iyfgsre8ofgieagftergieugrngeu62")
            {
                MessageBox.Show("Access Granted");
                this.Hide();
                main main = new main();
                main.Show();
            }
            else
            {
                MessageBox.Show("Invalid Code");
            }
        }
    }
}
